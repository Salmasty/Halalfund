
function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 to-white flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold text-green-700 mb-4">HalalFund</h1>
      <p className="text-gray-700 mb-6 text-center max-w-md">
        A secure, transparent way to give sadaqah, zakat, and donations — powered by Web3.
      </p>
      <button className="bg-green-600 text-white px-6 py-3 rounded-full hover:bg-green-700 transition">
        Donate Now
      </button>
    </div>
  )
}

export default App
